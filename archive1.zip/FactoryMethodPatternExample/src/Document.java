
public interface Document {

}
