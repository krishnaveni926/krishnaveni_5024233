import java.util.List;
import java.util.ArrayList;
interface Stock {
    void registerObserver(Observer observer);
    void deregisterObserver(Observer observer);
    void notifyObservers();
}

class StockMarket implements Stock {
    private List<Observer> observers = new ArrayList<>();
    private String stockName;
    private double stockPrice;

    public StockMarket(String stockName, double stockPrice) {
        this.stockName = stockName;
        this.stockPrice = stockPrice;
    }

    @Override
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void deregisterObserver(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(stockName, stockPrice);
        }
    }

    public void setStockPrice(double newPrice) {
        this.stockPrice = newPrice;
        notifyObservers();
    }
}
interface Observer {
    void update(String stockName, double stockPrice);
}
class MobileApp implements Observer {
    private String appName;

    public MobileApp(String appName) {
        this.appName = appName;
    }

    @Override
    public void update(String stockName, double stockPrice) {
        System.out.println(appName + " received update: " + stockName + " new price: $" + stockPrice);
    }
}
class WebApp implements Observer {
    private String webAppName;

    public WebApp(String webAppName) {
        this.webAppName = webAppName;
    }

    @Override
    public void update(String stockName, double stockPrice) {
        System.out.println(webAppName + " received update: " + stockName + " new price: $" + stockPrice);
    }
}
public class ObserverPatternTest {
    public static void main(String[] args) {
        // Create a StockMarket (Subject)
        StockMarket stockMarket = new StockMarket("TechCorp", 150.00);

        // Create observers
        Observer mobileApp = new MobileApp("Tech News Mobile");
        Observer webApp = new WebApp("Tech News Web");

        // Register observers
        stockMarket.registerObserver(mobileApp);
        stockMarket.registerObserver(webApp);

        // Update stock price and notify observers
        stockMarket.setStockPrice(155.00);
        stockMarket.setStockPrice(160.00);

        // Deregister an observer
        stockMarket.deregisterObserver(mobileApp);

        // Update stock price and notify remaining observers
        stockMarket.setStockPrice(165.00);
    }
}
