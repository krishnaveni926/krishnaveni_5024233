interface CustomerRepository {
    String findCustomerById(String id);
}
class CustomerRepositoryImpl implements CustomerRepository {
    @Override
    public String findCustomerById(String id) {
        // In a real application, this method would connect to a database to retrieve customer data
        return "Customer with ID: " + id;
    }
}
class CustomerService {
    private CustomerRepository customerRepository;

    // Constructor injection
    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public String getCustomerDetails(String id) {
        return customerRepository.findCustomerById(id);
    }
}

public class DependencyInjectionTest {
    public static void main(String[] args) {
        // Create a CustomerRepository implementation
        CustomerRepository customerRepository = new CustomerRepositoryImpl();

        // Inject the CustomerRepository into the CustomerService
        CustomerService customerService = new CustomerService(customerRepository);

        // Use the CustomerService to get customer details
        String customerDetails = customerService.getCustomerDetails("1234");
        System.out.println(customerDetails);
    }
}
